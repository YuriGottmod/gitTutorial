﻿using System;

namespace Dop2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(add(1, 1));
        }

        public static int add(int a, int b)
        {
            if (b == 0) return a;
            int sum = a ^ b;      // добавляем без переноса
            int carry = (a & b) << 1;  // перенос без суммирования
            return add(sum, carry);    // рекурсия
        }
    }
}
