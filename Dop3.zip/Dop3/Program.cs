﻿using System;
using System.Math;

namespace Dop3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(rand(2,4));
        }

        public static int rand(int lower, int higher)
        {
            return lower + (int)(Math.random() * (higher - lower + 1));
        }

        /* Выбрать M элементов из исходного массива. Клонируемый исходный
        * массив так, чтобы не уничтожить ввод */
        public static int[] pickMRandomly(int[] original, int m)
        {
            int[] subset = new int[m];
            int[] array = original.clone();
            for (int j = 0; j < m; j++)
            {
                int index = rand(j, array.length - 1);
                subset[j] = array[index];
                array[index] = array[j]; //array[j] теперь "мертв"
            }
            return subset;
        }
    }
}
